<center><!--  center Begin  -->
    
    <h1> Pay Offline Using Method </h1>
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
            
                <th> Bank Account Details: </th>
                <th> Easy Paisa, UBL Omni, Mobi Cash Details: </th>
                <th> Western Union Details: </th>

            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <td> Bank Name: UBL | Account No: 180-839-032 | Branch Name: Lahore | Branch Code: 1498 </td>
           <td> NIC #980-231-907 | Mobile No: 0931-7894-9983 | Name: MrGhie </td>
           <td> Real Name: Mr Mughianto | Mobile No: 0931-7894-9983 Country: Pakistan | Name: MrGhie | NIC #980-231-907 </td>
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->